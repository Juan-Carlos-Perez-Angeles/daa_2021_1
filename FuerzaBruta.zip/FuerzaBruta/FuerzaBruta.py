Texto = """El lema que anima a la Universidad Nacional, Por mi raza hablará el espíritu, revela la vocación 
humanística con la que fue concebida. El autor de esta célebre frase, José Vasconcelos, asumió la rectoría 
en 1920, en una época en que las esperanzas de la Revolución aún estaban vivas, había una gran fe en la Patria 
y el ánimo redentor se extendía en el ambiente.
"""
Quitar = ",;:.\n!\"'"
for Caracter in Quitar:
    Texto = Texto.replace(Caracter, "")
Texto = Texto.lower()
Palabras = Texto.split(" ")
Diccionario_Frecuencias = {}
for Palabra in Palabras:
    if Palabra in Diccionario_Frecuencias:
        Diccionario_Frecuencias[Palabra] += 1
    else:
        Diccionario_Frecuencias[Palabra] = 1
for Palabra in Diccionario_Frecuencias:
    Frecuencia = Diccionario_Frecuencias[Palabra]
    print(f"La palabra '{Palabra}' tiene una frecuencia de {Frecuencia}")