datos = [4,18,47,2,34,14,78,12,48,21,31,19,1,3,5]

def busq_lineal(L,buscando):
    indice = -1
    #contador += 1
    for idx in range (len(L)):
        if L[idx] == buscando:
            indice = idx
            break
        return indice

""" 
Busqueda Binaria

"""

def busqueda_binalria(L,buscado):
    IZQ = 0
    DER = len(L)-1
    MID = int((IZQ+DER)/2)
    if len(L)%2 == 0:
        MID = (DER/2)+1
    else:
        MID = DER // 2
    while (L[MID] != buscado):
        if L[MID] > buscado:
            DER = MID
        else:
            IZQ = MID
        if (DER - IZQ) % 2 == 0:
            MID = (IZQ+((DER-IZQ)//2))+1
        else:
            MID = IZQ + ((DER-IZQ)//2)
    return  MID
def main():
    datos = [4,18,47,2,34,14,78,12,48,21,31,19,1,3,5]
    dato = int(input("¿Que valor desea buscar? "))
    resultado = busq_lineal(datos,dato)
    print("Resultados: ",resultado)

    print("busqueda lineal en una lista ordenada")
    datos.sort()
    print(datos)
    resultado = busq_lineal(datos,dato)
    print("Resultado: ",resultado)

    print("Busqueda Binaria")
    posicion = busqueda_binalria(datos,dato)
    print(f"El resultado esta en :")
main()