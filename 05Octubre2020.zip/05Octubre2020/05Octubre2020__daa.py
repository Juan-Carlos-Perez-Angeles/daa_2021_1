"""
Estructura de datos pila(stack)

- Last In First Out (LIPO)
- De tipo lineal
- Se puede obtener e ingresar datos desde el tope
- Push para agregar
- Pop para sacar

Operaciones de las pilas

1. is_empty (regresa true o false)
2. get_top (ingresa elemento en el tope SIN SACARLO)
3. get_pop (Saca el elemento del tope y lo regresa)
4. get_push (mete un elemento en el tope)
5. get_length (regresa el numero de elemento en la pila)"""


class Stack:
    def __init__(self):
        self .__datos = []

    def is_empty(self):
        return len(self.__datos) == 0

    def get_top(self):
        return self.__datos[-1]

    def pop(self):
        return self.__datos.pop()

    def push(self,valor):
        self.__datos.append(valor)

    def get_length(self):
        return len(self.__datos)

    def to_string(self):
        print("|-----------|")
        for ele in self.__datos[-1::-1]:
            print(f" {ele}")
        print("|-----------|")

pila_1 = Stack()
pila_1.push(10)
pila_1.push(20)
pila_1.push(1)
pila_1.push(393)
pila_1.push(103)
pila_1.to_string()
sacado= pila_1.pop()
print(sacado)
pila_1.to_string()

print(f"El elemento en el tope es: {pila_1.get_top()}")
pila_1.to_string()
print(f"la pila tiene {pila_1.get_length()} elementos")
print(f"la pila esta vacia: {pila_1.is_empty()}")