from colored import fg, bg, attr
print ('%s Hello World !!! %s' % (fg(1), attr(0)))

print ('%s%s Hello World !!! %s' % (fg(1), bg(15), attr(0)))
