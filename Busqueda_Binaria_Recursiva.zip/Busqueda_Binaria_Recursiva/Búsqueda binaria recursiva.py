def busqueda_binaria(L, buscado):
    indice = -1
    IZQ = 0
    DER = len(L) - 1
    MID = 0
    while not (IZQ > DER):
        MID = (IZQ + DER) // 2
        if (L[MID] < buscado):
            IZQ = MID + 1
        else:
            DER = MID - 1
        print(f"Comparar buscado:{buscado} con {L[MID]}")
        if L[MID] == buscado:
            indice = MID
            break
    return indice


"""Busqueda binaria recursiva"""


def busqueda_binaria_recursiva(L, buscado):
    if len(L) == 0:
        return ("Lista Vacia")
    else:
        MID = len(L) // 2

        if L[MID] == buscado:
            return MID
        else:
            if buscado < L[MID]:
                return busqueda_binaria(L[:MID],buscado)
            else:
                return busqueda_binaria(L[MID + 1:], buscado)

L=[4,7,3,9,5,6,10]
busqueda_binaria_recursiva(L,5)